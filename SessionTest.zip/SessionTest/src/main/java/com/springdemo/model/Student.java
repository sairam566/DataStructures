package com.springdemo.model;

import java.util.LinkedHashMap;

public class Student
{
	private String firstName;
	private String lastName;
	private String language;
	private String country;
	private String languageChoosen;
	private String[] checkList;
	
	
	
	public String[] getCheckList() {
		return checkList;
	}

	public void setCheckList(String[] checkList) {
		this.checkList = checkList;
	}

	public String getLanguageChoosen() {
		return languageChoosen;
	}

	public void setLanguageChoosen(String languageChoosen) {
		this.languageChoosen = languageChoosen;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	private LinkedHashMap<String,String> listOfContrys;
	
	
	
	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public Student()
	{
		listOfContrys= new LinkedHashMap<String, String>();
		listOfContrys.put("BR", "Brazil");
		listOfContrys.put("IN", "India");
		listOfContrys.put("US", "USA");
	}

	
	public LinkedHashMap<String, String> getListOfContrys() {
		return listOfContrys;
	}

	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
}
