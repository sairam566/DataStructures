package com.springdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class FrontController 
{
	@RequestMapping(value="/req")
	public String homePage()
	{
		return "success";
	}
	
	@RequestMapping(value="/login")
	public String loginValidator()
	{
		return "redirect:student/loginform";
	}
}
