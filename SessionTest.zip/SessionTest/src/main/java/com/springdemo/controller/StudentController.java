package com.springdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springdemo.model.Student;

@Controller
@RequestMapping("/student")
public class StudentController 
{
	@RequestMapping("/loginform")
	public String login(Model model)
	{
		//create student Object
		Student student=new Student();
		
		//Add student Object to the Model Object
		model.addAttribute("student",student);
		
		return "studentLogin";
	}
	
	@RequestMapping("/processform")
	public String proceessForm(@ModelAttribute("student") Student student)
	{
		return "studentDetailes";
	}
}
